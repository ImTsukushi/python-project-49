#!/usr/bin/env python3
from brain_games.games import brain_progression

brain_progression()


def main():
    brain_progression()


if __name__ == '__main__':
    main()
