from brain_games.games.even import brain_even
from brain_games.games.calc import brain_calc
from brain_games.games.gcd import brain_gcd
