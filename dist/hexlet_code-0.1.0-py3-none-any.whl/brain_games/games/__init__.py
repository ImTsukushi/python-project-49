from brain_games.games.even import brain_even
from brain_games.games.calc import brain_calc
